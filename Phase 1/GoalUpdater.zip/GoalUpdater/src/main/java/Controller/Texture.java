package Controller;

import java.util.ArrayList;

public class Texture extends Rectangle {

    private int parameter1,parameter2;

    public Texture(int x1, int x2, int x3, int x4, int x5, int x6){
        super(x1,x2,x3,x4);
        this.parameter1 = x5;
        this.parameter2 = x6;
    }

}
