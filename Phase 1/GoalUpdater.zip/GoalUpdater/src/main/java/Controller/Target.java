package Controller;

public class Target extends Rectangle{

    public Target(int x1, int y1, int x3, int y3) {
        super(x1, y1, x3, y3);
    }
}
